
For this project to run follow below commands<br>

to set up node
WINDOWS:
# Download and install fnm:
winget install Schniz.fnm
# Download and install Node.js:
fnm install 22
# Verify the Node.js version:
node -v # Should print "v22.13.1".
# Verify npm version:
npm -v # Should print "10.9.2".
# install angular
npm install -g @angular/cli@17

macOS & Linux:
# Download and install fnm:
curl -o- https://fnm.vercel.app/install | bash
# Download and install Node.js:
fnm install 22
# Verify the Node.js version:
node -v # Should print "v22.13.1".
# Verify npm version:
npm -v # Should print "10.9.2".
# install angular
npm install -g @angular/cli@17

**npm i**

**ng serve**
